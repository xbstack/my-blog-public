# GitHub Issue reply draft

I reproduced the Baserow parameter dependency failure with the exact package sets declared by n8n 2.32.7, 2.33.4/2.33.5, and 2.34.2.

Environment for the isolated resolver test:

- macOS
- Node.js 22.18.0
- n8n 2.32.7 -> `n8n-workflow@2.32.1` + `n8n-nodes-base@2.32.4`
- n8n 2.33.4 / 2.33.5 -> `n8n-workflow@2.33.1` + `n8n-nodes-base@2.33.1`
- n8n 2.34.2 pre-release -> `n8n-workflow@2.34.1` + `n8n-nodes-base@2.34.1`

Results:

1. 2.32.7 dependency set: nested Baserow filter fields are `field / operator / value`; `getNodeParameters()` returns OK.
2. 2.33.x dependency set: the nested list adds `timezone`, whose `displayOptions.show` depends on `../operator`; `getNodeParameters()` reproduces the exact error:

```text
Could not resolve parameter dependencies. Max iterations reached!
Hint: If displayOptions are specified in any child parameter of a parent collection or fixedCollection, remove the displayOptions from the child parameter.
```

3. 2.34.2 pre-release's `2.34.1 + 2.34.1` package set still reproduces the same error.
4. Diagnostic check only: cloning the 2.33.x schema in memory and changing the timezone dependency key from `../operator` to sibling `operator` makes the exact same resolver call pass. I am not proposing this as a production patch until maintainers confirm the intended parameter path and full n8n tests pass.

This reproduction requires no Baserow credential, database, or network call, so this failure path is independent of instance credentials.

Minimal repo: <PUBLIC_REPO_URL>
Detailed write-up: https://www.xbstack.com/en/ai/n8n-baserow-parameter-dependencies-activation-error/?utm_source=github&utm_medium=referral&utm_campaign=n8n_baserow_parameter_dependencies&utm_content=issue_comment
